-- PostgreSQL Database Backup Simulation
-- Created: 2026-02-02 08:37:53
-- Database: absensi_qr
-- Host: 127.0.0.1

-- Table: schools (34 records)
-- Table: users (1007 records)
-- Table: attendances (0 records)
