-- PostgreSQL Database Backup Simulation
-- Created: 2026-02-02 08:47:54
-- Database: absensi_qr
-- Host: 127.0.0.1

-- Table: schools (38 records)
-- Table: users (1162 records)
-- Table: attendances (0 records)
